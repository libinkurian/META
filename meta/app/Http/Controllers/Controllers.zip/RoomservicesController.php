<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Roomservices;

class RoomservicesController extends Controller
{
    public function listroomservices()
    {
        $data = Roomservices::all();

        return response()->json([
            'status_code' => '200',
            'data' => $data,
        ]);
    }

    public function addroomservices(Request $request)
    {
        Roomservices::create([
            'towels' => $request->towels,
            'cleaning' => $request->cleaning,
            'bed' => $request->bed,
            'turndown' => $request->turndown,
            'pillow' => $request->pillow,
        ]);

        return response()->json([
            'status_code' => '200',
            'message' => "Room services added successfully!",
        ]);
    }
}
