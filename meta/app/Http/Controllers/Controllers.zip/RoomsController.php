<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rooms;

class RoomsController extends Controller
{
    public function addrooms($hotel_id, Request $request)
    {
        Rooms::create([
            'hotel_id' => $hotel_id,
            'room_name' => $request->room_name,
            'num_rooms' => $request->num_rooms,
            'area_sqmtr' => $request->area_sqmtr,
            'room_type'=> $request->room_type
        ]);

        return response()->json([
            'status_code' => '200',
            'message' => 'Room added successfully!'
        ]);
    }

    public function listrooms($hotel_id)
    {
        $data = Rooms::where('hotel_id', $hotel_id)->get()->all();
        
        return response()->json([
            'status_code' => '200',
            'data' => $data
        ]);
    }
}
