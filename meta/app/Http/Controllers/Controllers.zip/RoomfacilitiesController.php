<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Roomfacilities;

class RoomfacilitiesController extends Controller
{
    public function addroomfacilities($room_id, Request $request)
    {
        Roomfacilities::create([
            'room_id' => $room_id,
            'facility_id' => $request->facility_id,
            'featured_id' => $request->featured_id,
        ]);

        return response()->json([
            'status_code' => '200',
            'message' => 'Facilities added successfully!'
        ]);
    }

    public function listroomfacilities($room_id)
    {
        $data = Roomfacilities::where('room_id', $room_id)->get()->all();
        
        return response()->json([
            'status_code' => '200',
            'data' => $data
        ]);
    }
}
