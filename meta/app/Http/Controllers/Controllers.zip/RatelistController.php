<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ratelist;

class RatelistController extends Controller
{
    public function listratelist($hotel_id)
    {
        $data = Ratelist::where('hotel_id', $hotel_id)->get()->all();

        return response()->json([
            'status_code' => '200',
            'data' => $data,
        ]);
    }

    public function addratelist($hotel_id, Request $request)
    {
        Ratelist::create([
            'hotel_id' => $hotel_id,
            'public_name' => $request->public_name,
            'internal_name' => $request->internal_name,
            'min_lead_days' => $request->min_lead_days,
            'currency' => $request->currency,
            'markets' => $request->markets,
            'confidential' => $request->confidential,
            'assign_rooms' => $request->assign_rooms,
            'boards' => $request->boards,
            'assigned_policies' => json_encode($request->assigned_policies),
            'default_policy' => $request->default_policy,
            'ref_cal' => $request->ref_cal,
            'status' => $request->status,
        ]);

        return response()->json([
            'status_code' => '200',
            'message' => "Policies added successfully!",
        ]);
    }
}
