<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Extra extends Model
{
    use HasFactory;
    protected $table = 'uhb_extras';
    public $timestamps = false;
  
    protected $fillable = [
        'hotel_id', 'checkforDays', 'reservation_type', 'rooms', 'rates', 'price_type',
        'price_per_num_persons', 'price', 'price2', 'price3', 'price4', 'price5', 'price6',
        'price7', 'price8', 'price9', 'price10', 'price11', 'price12', 'canChooseDaysToApplyAux',
        'ageCategory', 'minStay', 'maxStay', 'daysInAdvance', 'maximum_count', 'image',
        'provider', 'notifyEmail', 'priority_order', 'is_active'
    ];
}
