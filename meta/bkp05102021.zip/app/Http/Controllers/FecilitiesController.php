<?php

namespace App\Http\Controllers;
use App\Models\Fecilities;

use Illuminate\Http\Request;

class FecilitiesController extends Controller
{
//     public function listfecilities()
//            {
//              $Fecilities= Fecilities::all();
//              $data['fecilities']=$Fecilities;
//              return response()->json(compact('data'),200);
//            }   
}
