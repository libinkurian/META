<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Extraitems;

class ExtraitemsController extends Controller
{
    public function extraitems()
    {
        $extraitems = Extraitems::all();

        return response()->json([
            'status' => '200',
            'data' => $extraitems
        ]);
    }

    public function addextraitems(Request $request)
    {
        $validatedData = $request->validate([
            'extra_id' => 'required',
            'Parent_id' => 'required',
            'language_id' => 'required',
            'name' => 'required',
            'subtitle' => 'required',
            'description' => 'required',
            'conditions' => 'required',
        ]);

        Extraitems::create([
            'extra_id' => $validatedData['extra_id'],
            'Parent_id' => $validatedData['Parent_id'],
            'language_id' => $validatedData['language_id'],
            'name' => $validatedData['name'],
            'subtitle' => $validatedData['subtitle'],
            'description' => $validatedData['description'],
            'conditions' => $validatedData['conditions'],
        ]);

        return response()->json([
            'status_code' => '200',
            'message' => "Item added successfully!",
        ]);
    }
}
