<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fecilities extends Model
{
    use HasFactory;
    protected $table = "uhb_room_facilities";
}
